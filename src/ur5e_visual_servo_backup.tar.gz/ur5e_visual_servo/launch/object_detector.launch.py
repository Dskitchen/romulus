from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='ur5e_visual_servo',
            executable='object_detector.py',
            name='object_detector',
            output='screen',
            parameters=[{
                'detection_enabled': True,
                'debug_images': True,
                'checkerboard_rows': 6,
                'checkerboard_cols': 8,
                'square_size': 0.023
            }]
        )
    ])
