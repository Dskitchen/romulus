# svg_pattern_projector.launch.py
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
import os
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # Get the package share directory
    pkg_share = get_package_share_directory('ur5e_visual_servo')
    
    # Set defaults
    default_svg_directory = os.path.join(os.path.expanduser('~'), 'decoration_patterns')
    
    # If there's a patterns directory in the package, use that instead
    package_patterns_dir = os.path.join(pkg_share, 'decoration_patterns')
    if os.path.exists(package_patterns_dir):
        default_svg_directory = package_patterns_dir
    
    return LaunchDescription([
        # Define launch arguments
        DeclareLaunchArgument(
            'svg_directory',
            default_value=default_svg_directory,
            description='Directory containing SVG decoration patterns'
        ),
        
        DeclareLaunchArgument(
            'pattern_scale',
            default_value='0.8',
            description='Scale factor for pattern (0-1)'
        ),
        
        # Define the node
        Node(
            package='ur5e_visual_servo',
            executable='svg_pattern_projector.py',
            name='svg_pattern_projector',
            output='screen',
            parameters=[{
                'svg_directory': LaunchConfiguration('svg_directory'),
                'pattern_scale': LaunchConfiguration('pattern_scale')
            }],
            # Optional remappings if needed
            remappings=[
                ('/object_detection/cake_surface', '/object_detection/cake_surface'),
                ('/object_detection/select_pattern', '/object_detection/select_pattern'),
                ('/object_detection/pattern_markers', '/object_detection/pattern_markers'),
                ('/visual_servo/decoration_point', '/visual_servo/decoration_point')
            ]
        )
    ])
