from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='ur5e_visual_servo',
            executable='gui_interface.py',
            name='visual_servo_gui',
            output='screen'
        )
    ])
