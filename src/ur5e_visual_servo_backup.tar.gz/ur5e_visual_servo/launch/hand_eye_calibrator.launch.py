from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='ur5e_visual_servo',
            executable='hand_eye_calibrator.py',
            name='hand_eye_calibrator',
            output='screen'
        )
    ])
