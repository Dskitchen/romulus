from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='ur5e_visual_servo',
            executable='visual_servo_controller.py',
            name='visual_servo_controller',
            output='screen',
            parameters=[{
                'servo_enabled': False,
                'manual_control_speed': 0.1,
                'max_speed': 0.2,
                'robot_mode': 'manual',
                'emergency_stop_timeout': 0.5,
                'pixel_error_threshold': 50.0,
                'servo_gain': 0.001
            }]
        )
    ])
