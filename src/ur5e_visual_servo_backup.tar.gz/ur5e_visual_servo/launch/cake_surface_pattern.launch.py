from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    pkg_share = get_package_share_directory('ur5e_visual_servo')
    rviz_config = os.path.join(pkg_share, 'config', 'cake_surface.rviz')
    
    return LaunchDescription([
        # ZED wrapper
        Node(
            package='zed_wrapper',
            executable='zed_wrapper',
            name='zed_wrapper',
            output='screen',
            arguments=['--ros-args', '--params-file', '/opt/ros/humble/share/zed_wrapper/config/zedx.yaml']
        ),
        # Surface detector
        Node(
            package='ur5e_visual_servo',
            executable='cake_surface_detector.py',
            name='cake_surface_detector',
            output='screen',
            parameters=[{
                'max_surface_angle': 45.0,
                'min_surface_area': 0.005,
                'max_surface_area': 1.0,
                'plane_distance_threshold': 0.02
            }]
        ),
        # SVG pattern projector
        Node(
            package='ur5e_visual_servo',
            executable='svg_pattern_projector.py',
            name='svg_pattern_projector',
            output='screen',
            parameters=[{
                'svg_directory': os.path.expanduser('~/decoration_patterns'),
                'pattern_scale': 0.8
            }]
        ),
        # RViz
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen',
            arguments=['-d', rviz_config] if os.path.exists(rviz_config) else []
        )
    ])
