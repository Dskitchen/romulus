# zed_surface_detector.launch.py
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            'max_surface_angle',
            default_value='25.0',
            description='Maximum angle in degrees for horizontal surfaces'
        ),
        
        DeclareLaunchArgument(
            'min_surface_area',
            default_value='0.01',
            description='Minimum area in m² for cake surfaces'
        ),
        
        DeclareLaunchArgument(
            'max_surface_area',
            default_value='0.5',
            description='Maximum area in m² for cake surfaces'
        ),
        
        DeclareLaunchArgument(
            'plane_distance_threshold',
            default_value='0.01',
            description='Maximum distance for points to be considered on the same plane (meters)'
        ),
        
        DeclareLaunchArgument(
            'downsample_factor',
            default_value='10',
            description='Downsample factor for point cloud (1 = no downsample, 10 = keep 1/10 points)'
        ),
        
        DeclareLaunchArgument(
            'max_coord',
            default_value='10.0',
            description='Maximum valid coordinate value (meters)'
        ),
        
        DeclareLaunchArgument(
            'min_points_for_plane',
            default_value='20',
            description='Minimum number of points required for plane detection'
        ),
        
        Node(
            package='ur5e_visual_servo',
            executable='zed_surface_detector.py',
            name='zed_surface_detector',
            output='screen',
            arguments=['--ros-args', '--log-level', 'DEBUG'],  # Enable debug logging
            parameters=[{
                'max_surface_angle': LaunchConfiguration('max_surface_angle'),
                'min_surface_area': LaunchConfiguration('min_surface_area'),
                'max_surface_area': LaunchConfiguration('max_surface_area'),
                'plane_distance_threshold': LaunchConfiguration('plane_distance_threshold'),
                'downsample_factor': LaunchConfiguration('downsample_factor'),
                'max_coord': LaunchConfiguration('max_coord'),
                'min_points_for_plane': LaunchConfiguration('min_points_for_plane')
            }]
        )
    ])
