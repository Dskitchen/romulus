from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    # Get the package share directory
    pkg_share = get_package_share_directory('ur5e_visual_servo')
    
    # Path to the URDF file
    urdf_file = os.path.join(pkg_share, 'urdf', 'romulus.urdf')
    
    # Read the URDF file
    with open(urdf_file, 'r') as infp:
        robot_desc = infp.read()

    return LaunchDescription([
        # Publish the robot description using robot_state_publisher
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': robot_desc}]
        ),
        # Static transform publisher from tool0 to zed_camera_link
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='tool0_to_zedx_transform',
            output='screen',
            arguments=['--frame-id', 'tool0', '--child-frame-id', 'zed_camera_link',
                       '--x', '-0.065', '--y', '-0.016', '--z', '0.0175',  # Adjusted z
                       '--roll', '3.14159', '--pitch', '-1.5708', '--yaw', '3.14159']
        ),
    ])
