#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, TransformStamped
from std_msgs.msg import String
import tf2_ros
import numpy as np
import cv2
from scipy.spatial.transform import Rotation

class HandEyeCalibrator(Node):
    def __init__(self):
        super().__init__('hand_eye_calibrator')

        # TF buffer and broadcaster
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        self.tf_broadcaster = tf2_ros.StaticTransformBroadcaster(self)

        # Subscriber for calibration snapshots
        self.snapshot_sub = self.create_subscription(
            PoseStamped,
            '/calibration/snapshot',
            self.snapshot_callback,
            10)

        # Publisher for status
        self.status_pub = self.create_publisher(
            String,
            '/calibration/status',
            10)

        # Storage for calibration data
        self.robot_poses = []  # base to tool0
        self.checkerboard_poses = []  # zedx_camera_center to checkerboard

        self.get_logger().info('Hand-eye calibrator initialized')
        self.get_logger().info('Waiting for calibration snapshots... Collect at least 5 poses.')

    def snapshot_callback(self, msg):
        if msg.header.frame_id != 'calibration_snapshot':
            return

        # Extract checkerboard pose (zedx_camera_center to checkerboard)
        checkerboard_pose = [
            msg.pose.position.x,
            msg.pose.position.y,
            msg.pose.position.z,
            msg.pose.orientation.x,
            msg.pose.orientation.y,
            msg.pose.orientation.z,
            msg.pose.orientation.w
        ]

        # Get robot pose (base to tool0) at the same timestamp
        try:
            transform = self.tf_buffer.lookup_transform(
                'base',
                'tool0',
                msg.header.stamp,
                timeout=rclpy.duration.Duration(seconds=1.0)
            )
            robot_pose = [
                transform.transform.translation.x,
                transform.transform.translation.y,
                transform.transform.translation.z,
                transform.transform.rotation.x,
                transform.transform.rotation.y,
                transform.transform.rotation.z,
                transform.transform.rotation.w
            ]
        except Exception as e:
            self.get_logger().error(f"Failed to get robot pose: {str(e)}")
            return

        # Store poses
        self.robot_poses.append(robot_pose)
        self.checkerboard_poses.append(checkerboard_pose)

        self.get_logger().info(f"Collected snapshot {len(self.robot_poses)}:")
        self.get_logger().info(f"Robot pose: {robot_pose}")
        self.get_logger().info(f"Checkerboard pose: {checkerboard_pose}")

        status_msg = String()
        status_msg.data = f"Collected {len(self.robot_poses)} snapshots. Need at least 5 to compute transform."
        self.status_pub.publish(status_msg)

        # Compute transform if we have enough poses
        if len(self.robot_poses) >= 5:
            self.compute_hand_eye_transform()
            self.robot_poses.clear()
            self.checkerboard_poses.clear()

    def compute_hand_eye_transform(self):
        if len(self.robot_poses) < 3:
            self.get_logger().error("Not enough poses for calibration (minimum 3 required)")
            return

        R_gripper2base = []
        T_gripper2base = []
        R_target2cam = []
        T_target2cam = []

        for rp, cp in zip(self.robot_poses, self.checkerboard_poses):
            # Robot pose (base to tool0): [x, y, z, qx, qy, qz, qw]
            robot_pos = np.array([rp[0], rp[1], rp[2]])
            robot_quat = np.array([rp[3], rp[4], rp[5], rp[6]])  # [qx, qy, qz, qw]
            # Convert quaternion to rotation matrix
            robot_rot = Rotation.from_quat([robot_quat[0], robot_quat[1], robot_quat[2], robot_quat[3]])  # [qx, qy, qz, qw]
            R_gripper2base.append(robot_rot.as_matrix())
            T_gripper2base.append(robot_pos)

            # Checkerboard pose (zedx_camera_center to checkerboard): [x, y, z, qx, qy, qz, qw]
            checkerboard_pos = np.array([cp[0], cp[1], cp[2]])
            checkerboard_quat = np.array([cp[3], cp[4], cp[5], cp[6]])  # [qx, qy, qz, qw]
            # Convert quaternion to rotation matrix
            checkerboard_rot = Rotation.from_quat([checkerboard_quat[0], checkerboard_quat[1], checkerboard_quat[2], checkerboard_quat[3]])
            R_target2cam.append(checkerboard_rot.as_matrix())
            T_target2cam.append(checkerboard_pos)

        # Convert lists to NumPy arrays
        R_gripper2base = np.array(R_gripper2base)
        T_gripper2base = np.array(T_gripper2base)
        R_target2cam = np.array(R_target2cam)
        T_target2cam = np.array(T_target2cam)

        # Perform hand-eye calibration
        R_cam2gripper, T_cam2gripper = cv2.calibrateHandEye(
            R_gripper2base, T_gripper2base,
            R_target2cam, T_target2cam,
            method=cv2.CALIB_HAND_EYE_TSAI
        )

        # Convert rotation matrix to quaternion
        cam2gripper_rot = Rotation.from_matrix(R_cam2gripper)
        cam2gripper_quat = cam2gripper_rot.as_quat()  # [qx, qy, qz, qw]
        qx, qy, qz, qw = cam2gripper_quat  # Unpack directly

        # Publish static transform
        transform = TransformStamped()
        transform.header.stamp = self.get_clock().now().to_msg()
        transform.header.frame_id = 'tool0'
        transform.child_frame_id = 'zedx_camera_center'
        transform.transform.translation.x = float(T_cam2gripper[0][0])
        transform.transform.translation.y = float(T_cam2gripper[1][0])
        transform.transform.translation.z = float(T_cam2gripper[2][0])
        transform.transform.rotation.x = qx
        transform.transform.rotation.y = qy
        transform.transform.rotation.z = qz
        transform.transform.rotation.w = qw
        self.tf_broadcaster.sendTransform(transform)

        self.get_logger().info(f"Published static transform from tool0 to zedx_camera_center:")
        self.get_logger().info(f"Translation: {T_cam2gripper[0][0]:.6f}, {T_cam2gripper[1][0]:.6f}, {T_cam2gripper[2][0]:.6f}")
        self.get_logger().info(f"Quaternion: {qw:.6f}, {qx:.6f}, {qy:.6f}, {qz:.6f}")

        status_msg = String()
        status_msg.data = f"Calibration complete: Transform published"
        self.status_pub.publish(status_msg)

def main(args=None):
    rclpy.init(args=args)
    calibrator = HandEyeCalibrator()
    rclpy.spin(calibrator)
    calibrator.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
