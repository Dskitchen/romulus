#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, String, Empty, Float32
from geometry_msgs.msg import PoseStamped, TransformStamped, PointStamped
from sensor_msgs.msg import Image, CompressedImage
from cv_bridge import CvBridge, CvBridgeError
import tkinter as tk
from tkinter import ttk, scrolledtext
from PIL import Image as PILImage
from PIL import ImageTk, ImageEnhance, ImageFilter
import threading
import numpy as np
import cv2
import time
import tf2_ros
import tf2_geometry_msgs
import os
from ament_index_python.packages import get_package_share_directory

class VisualServoGUI(Node):
    def __init__(self):
        super().__init__('visual_servo_gui')
        
        # CV Bridge
        self.bridge = CvBridge()
        
        # TF buffer and listener
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        
        # Company color scheme from Rise Baking logo
        self.company_blue = "#1a5b96"  # Rise Baking blue
        self.company_gold = "#ffc72c"  # Rise Baking gold
        self.background_light = "#f5f5f5"  # Light gray background
        self.text_dark = "#333333"  # Dark text
        
        # Add initialization waiting period to let camera stabilize
        self.enable_processing = False
        self.get_logger().info("Waiting for system to stabilize...")
        self.init_timer = self.create_timer(3.0, self.init_timer_callback)
        
        # For logging throttling
        self.log_counter = 0
        
        # Prioritize compressed image topics (more efficient)
        self.processed_img_compressed_sub = self.create_subscription(
            CompressedImage, 
            '/object_detection/processed_image/compressed', 
            self.processed_image_compressed_callback, 
            10)
            
        self.raw_img_compressed_sub = self.create_subscription(
            CompressedImage, 
            '/zed/zed_node/rgb/image_rect_color/compressed', 
            self.raw_image_compressed_callback, 
            10)
            
        # Fallback subscribers for uncompressed topics (only used if compressed not available)
        self.processed_img_uncompressed_sub = self.create_subscription(
            Image, 
            '/object_detection/processed_image', 
            self.processed_image_uncompressed_callback, 
            10)
            
        self.raw_img_uncompressed_sub = self.create_subscription(
            Image, 
            '/zed/zed_node/rgb/image_rect_color', 
            self.raw_image_uncompressed_callback, 
            10)
            
        self.detector_status_sub = self.create_subscription(
            String, 
            '/object_detection/status', 
            self.detector_status_callback, 
            10)
            
        self.servo_status_sub = self.create_subscription(
            String, 
            '/visual_servo/status', 
            self.servo_status_callback, 
            10)
            
        self.target_sub = self.create_subscription(
            PointStamped, 
            '/visual_servo/current_target', 
            self.target_callback, 
            10)
            
        self.checkerboard_pose_sub = self.create_subscription(
            PoseStamped,
            '/object_detection/checkerboard_pose',
            self.checkerboard_pose_callback,
            10)
        
        # Publishers
        self.detection_enable_pub = self.create_publisher(
            Bool, 
            '/object_detection/enable', 
            10)
            
        self.detection_mode_pub = self.create_publisher(
            String,
            '/object_detection/mode',
            10)
            
        self.servo_enable_pub = self.create_publisher(
            Bool, 
            '/visual_servo/enable', 
            10)
            
        self.mode_pub = self.create_publisher(
            String, 
            '/visual_servo/mode', 
            10)
            
        self.manual_command_pub = self.create_publisher(
            String, 
            '/visual_servo/manual_command', 
            10)
            
        self.record_pose_pub = self.create_publisher(
            Empty,
            '/visual_servo/record_pose',
            10)
            
        self.calibration_snapshot_pub = self.create_publisher(
            PoseStamped,
            '/calibration/snapshot',
            10)
            
        # Publishers for speed and smoothing controls
        self.speed_pub = self.create_publisher(
            Float32,
            '/visual_servo/speed_factor',
            10)
            
        self.smoothing_pub = self.create_publisher(
            Float32,
            '/visual_servo/smoothing_factor',
            10)
        
        # Initialize state variables
        self.latest_processed_image = None
        self.latest_raw_image = None
        self.detector_status = "Initializing..."
        self.servo_status = "Initializing..."
        self.target_point = None
        self.current_checkerboard_pose = None
        self.detection_enabled = True
        self.detection_mode = "red_object"  # Default to red object detection
        self.servo_enabled = False
        self.robot_mode = "manual"
        self.show_raw_feed = False
        self.speed_factor = 2.0  # Higher default speed for faster robot movement
        self.smoothing_factor = 0.2  # Lower default smoothing for more responsive movement
        
        # TF transform storage
        self.base_to_tool0 = None
        self.tool0_to_zed_camera_link = None
        self.zed_camera_link_to_center = None
        
        # Watermark and logo images
        self.logo_image = None
        self.watermark_image = None
        self.watermark_tk = None
        
        # Create Tkinter root in a separate thread
        self.root = None
        self.image_label = None
        self.image_tk = None
        self.gui_thread = threading.Thread(target=self.create_gui)
        self.gui_thread.daemon = True
        self.gui_thread.start()
        
        self.get_logger().info('Visual servo GUI initialized, waiting for system to stabilize')
        
    def init_timer_callback(self):
        self.enable_processing = True
        self.get_logger().info("System stabilized, starting processing")
        # Publish initial states with improved defaults
        self.publish_initial_states()
        self.destroy_timer(self.init_timer)
        
    def publish_initial_states(self):
        detection_msg = Bool()
        detection_msg.data = self.detection_enabled
        self.detection_enable_pub.publish(detection_msg)
        
        detection_mode_msg = String()
        detection_mode_msg.data = self.detection_mode
        self.detection_mode_pub.publish(detection_mode_msg)
        
        servo_msg = Bool()
        servo_msg.data = self.servo_enabled
        self.servo_enable_pub.publish(servo_msg)
        
        mode_msg = String()
        mode_msg.data = self.robot_mode
        self.mode_pub.publish(mode_msg)
        
        # Publish initial speed and smoothing factors with improved defaults
        speed_msg = Float32()
        speed_msg.data = self.speed_factor
        self.speed_pub.publish(speed_msg)
        
        smoothing_msg = Float32()
        smoothing_msg.data = self.smoothing_factor
        self.smoothing_pub.publish(smoothing_msg)
    
    def processed_image_compressed_callback(self, msg):
        if not self.enable_processing:
            return
            
        try:
            # Convert compressed image to cv2 format
            np_arr = np.frombuffer(msg.data, np.uint8)
            cv_image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
            
            # Store the image without downscaling for better quality
            self.latest_processed_image = cv_image
        except Exception as e:
            self.get_logger().error(f"Error processing compressed image: {str(e)}")
            
    def raw_image_compressed_callback(self, msg):
        if not self.enable_processing:
            return
            
        try:
            # Convert compressed image to cv2 format
            np_arr = np.frombuffer(msg.data, np.uint8)
            cv_image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
            
            # Store the image without downscaling for better quality
            self.latest_raw_image = cv_image
        except Exception as e:
            self.get_logger().error(f"Error processing compressed raw image: {str(e)}")
    
    def processed_image_uncompressed_callback(self, msg):
        if not self.enable_processing:
            return
            
        # Only use this if compressed images aren't coming in
        if self.latest_processed_image is not None:
            return
            
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            self.latest_processed_image = cv_image
        except CvBridgeError as e:
            self.get_logger().error(f"Error processing uncompressed image: {str(e)}")

    def raw_image_uncompressed_callback(self, msg):
        if not self.enable_processing:
            return
            
        # Only use this if compressed images aren't coming in
        if self.latest_raw_image is not None:
            return
            
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            self.latest_raw_image = cv_image
        except CvBridgeError as e:
            self.get_logger().error(f"Error processing uncompressed raw image: {str(e)}")
    
    def detector_status_callback(self, msg):
        if not self.enable_processing:
            return
            
        self.detector_status = msg.data
        
    def servo_status_callback(self, msg):
        if not self.enable_processing:
            return
            
        self.servo_status = msg.data
        
    def target_callback(self, msg):
        if not self.enable_processing:
            return
            
        self.target_point = msg.point
        
    def checkerboard_pose_callback(self, msg):
        if not self.enable_processing:
            return
            
        self.current_checkerboard_pose = msg
    
    def create_watermark(self, width, height):
        # Try to find the logo in the ROS package or home directory
        try:
            # Search in common locations
            pkg_share = get_package_share_directory('ur5e_visual_servo')
            possible_paths = [
                os.path.join(pkg_share, 'media', 'rise_baking_logo.png'),
                os.path.expanduser('~/rise_baking_logo.png'),
                os.path.expanduser('~/catkin_ws/src/ur5e_visual_servo/media/rise_baking_logo.png')
            ]
            
            logo_path = None
            for path in possible_paths:
                if os.path.exists(path):
                    logo_path = path
                    break
                    
            if logo_path:
                # Create a blank canvas with the required dimensions
                watermark = PILImage.new('RGBA', (width, height), (255, 255, 255, 0))
                
                # Load and resize the logo
                logo = PILImage.open(logo_path).convert("RGBA")
                
                # Calculate the size for the watermark (half the width of canvas)
                watermark_width = width // 2
                watermark_height = int(watermark_width * logo.height / logo.width)
                
                logo = logo.resize((watermark_width, watermark_height), PILImage.LANCZOS)
                
                # Make the logo transparent
                enhancer = ImageEnhance.Brightness(logo)
                logo = enhancer.enhance(1.0)  # Full brightness
                
                # Apply opacity - extract alpha channel and modify it
                if logo.mode == 'RGBA':
                    r, g, b, a = logo.split()
                    a = a.point(lambda x: x * 0.15)  # 15% opacity
                    logo = PILImage.merge('RGBA', (r, g, b, a))
                
                # Calculate position to center the logo
                x = (width - watermark_width) // 2
                y = (height - watermark_height) // 2
                
                # Paste the logo onto the watermark
                watermark.paste(logo, (x, y), logo)
                
                return watermark
            else:
                self.get_logger().warn("Logo file not found for watermark")
                return None
                
        except Exception as e:
            self.get_logger().error(f"Error creating watermark: {str(e)}")
            return None
    
    def create_gui(self):
        self.root = tk.Tk()
        self.root.title("Rise Baking UR5e Visual Servoing Controller")
        self.root.geometry("1200x800")
        self.root.minsize(800, 600)
        
        # Set custom color scheme
        style = ttk.Style()
        style.configure("TFrame", background=self.background_light)
        style.configure("TLabel", background=self.background_light, foreground=self.text_dark)
        style.configure("TButton", background=self.company_blue, foreground="white", font=('Arial', 10, 'bold'))
        style.configure("TCheckbutton", background=self.background_light, foreground=self.text_dark)
        style.configure("TRadiobutton", background=self.background_light, foreground=self.text_dark)
        
        # Configure custom styles for different widgets
        style.configure("Blue.TButton", background=self.company_blue, foreground="white")
        style.configure("Gold.TButton", background=self.company_gold, foreground=self.text_dark)
        style.configure("Stop.TButton", background="#e74c3c", foreground="white", font=('Arial', 10, 'bold'))
        style.configure("Header.TLabel", font=('Arial', 12, 'bold'), foreground=self.company_blue)
        style.configure("Title.TLabel", font=('Arial', 14, 'bold'), foreground=self.company_blue)
        style.configure("Status.TLabel", font=('Arial', 10))
        style.configure("Info.TLabel", foreground=self.company_blue, font=('Arial', 10))
        style.configure("Blue.Horizontal.TProgressbar", background=self.company_blue)
        style.configure("Gold.Horizontal.TProgressbar", background=self.company_gold)
        
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Header frame with logo
        header_frame = ttk.Frame(main_frame)
        header_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Rise Baking logo
        try:
            # Try to find the logo in the ROS package
            pkg_share = get_package_share_directory('ur5e_visual_servo')
            logo_path = os.path.join(pkg_share, 'media', 'rise_baking_logo.png')
            
            if not os.path.exists(logo_path):
                # If the logo isn't found in the package, try a fallback path
                logo_path = os.path.expanduser('~/rise_baking_logo.png')
                
            if os.path.exists(logo_path):
                logo_img = PILImage.open(logo_path)
                logo_img = logo_img.resize((120, 80), PILImage.LANCZOS)
                self.logo_image = ImageTk.PhotoImage(logo_img)
                logo_label = ttk.Label(header_frame, image=self.logo_image, background=self.background_light)
                logo_label.pack(side=tk.LEFT, padx=10)
            else:
                # Create text logo if image not found
                logo_label = ttk.Label(header_frame, text="RISE BAKING", style="Title.TLabel")
                logo_label.pack(side=tk.LEFT, padx=10)
                
        except Exception as e:
            self.get_logger().warn(f"Could not load logo: {str(e)}")
            # Create text logo if image loading fails
            logo_label = ttk.Label(header_frame, text="RISE BAKING", style="Title.TLabel")
            logo_label.pack(side=tk.LEFT, padx=10)
            
        title_label = ttk.Label(header_frame, text="UR5e Visual Servoing Controller", style="Title.TLabel")
        title_label.pack(side=tk.LEFT, padx=20)
        
        paned_window = ttk.PanedWindow(main_frame, orient=tk.HORIZONTAL)
        paned_window.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        left_frame = ttk.Frame(paned_window, width=640, height=480)
        paned_window.add(left_frame, weight=3)
        
        right_frame = ttk.Frame(paned_window, width=400)
        paned_window.add(right_frame, weight=1)
        
        left_frame.pack_propagate(False)
        
        camera_frame = ttk.LabelFrame(left_frame, text="Camera View")
        camera_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Container for overlaying watermark and camera feed
        self.camera_container = ttk.Frame(camera_frame)
        self.camera_container.pack(fill=tk.BOTH, expand=True)
        
        # Label for the watermark (behind the camera feed)
        self.watermark_label = ttk.Label(self.camera_container)
        self.watermark_label.place(relwidth=1, relheight=1)
        
        # Label for the camera feed (on top of watermark)
        self.image_label = ttk.Label(self.camera_container, text="Waiting for camera feed...")
        self.image_label.place(relwidth=1, relheight=1)
        
        camera_control_frame = ttk.Frame(camera_frame)
        camera_control_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.show_raw_var = tk.BooleanVar(value=self.show_raw_feed)
        
        raw_btn = ttk.Radiobutton(
            camera_control_frame,
            text="Raw Camera Feed",
            variable=self.show_raw_var,
            value=True,
            command=self.toggle_camera_feed
        )
        raw_btn.pack(side=tk.LEFT, padx=5)
        
        processed_btn = ttk.Radiobutton(
            camera_control_frame,
            text="Processed Feed",
            variable=self.show_raw_var,
            value=False,
            command=self.toggle_camera_feed
        )
        processed_btn.pack(side=tk.LEFT, padx=5)
        
        self.fps_label = ttk.Label(camera_control_frame, text="FPS: --")
        self.fps_label.pack(side=tk.RIGHT, padx=5)
        
        # Status frame with improved styling
        status_frame = ttk.LabelFrame(right_frame, text="Status")
        status_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.detector_status_label = ttk.Label(status_frame, text="Detector: Initializing...", style="Status.TLabel")
        self.detector_status_label.pack(anchor=tk.W, padx=5, pady=2)
        
        self.servo_status_label = ttk.Label(status_frame, text="Servo: Initializing...", style="Status.TLabel")
        self.servo_status_label.pack(anchor=tk.W, padx=5, pady=2)
        
        self.camera_coords_label = ttk.Label(status_frame, text="Pixel Coords: None", foreground="red", style="Status.TLabel")
        self.camera_coords_label.pack(anchor=tk.W, padx=5, pady=2)
        
        self.target_coords_label = ttk.Label(status_frame, text="Target: None", style="Status.TLabel")
        self.target_coords_label.pack(anchor=tk.W, padx=5, pady=2)
        
        # Detection mode frame
        detection_mode_frame = ttk.LabelFrame(right_frame, text="Detection Mode")
        detection_mode_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.detection_mode_var = tk.StringVar(value=self.detection_mode)
        
        calibration_radio = ttk.Radiobutton(
            detection_mode_frame, 
            text="Calibration Mode (Checkerboard)", 
            variable=self.detection_mode_var, 
            value="calibration",
            command=self.update_detection_mode
        )
        calibration_radio.pack(anchor=tk.W, padx=5, pady=2)
        
        red_object_radio = ttk.Radiobutton(
            detection_mode_frame, 
            text="Red Object Detection", 
            variable=self.detection_mode_var, 
            value="red_object",
            command=self.update_detection_mode
        )
        red_object_radio.pack(anchor=tk.W, padx=5, pady=2)
        
        # Operation mode frame
        mode_frame = ttk.LabelFrame(right_frame, text="Operation Mode")
        mode_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.mode_var = tk.StringVar(value=self.robot_mode)
        
        manual_radio = ttk.Radiobutton(
            mode_frame, 
            text="Manual Control", 
            variable=self.mode_var, 
            value="manual",
            command=self.update_mode
        )
        manual_radio.pack(anchor=tk.W, padx=5, pady=2)
        
        auto_radio = ttk.Radiobutton(
            mode_frame, 
            text="Auto Servoing", 
            variable=self.mode_var, 
            value="auto",
            command=self.update_mode
        )
        auto_radio.pack(anchor=tk.W, padx=5, pady=2)
        
        # Controls frame
        control_frame = ttk.LabelFrame(right_frame, text="Controls")
        control_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.detection_var = tk.BooleanVar(value=self.detection_enabled)
        detection_check = ttk.Checkbutton(
            control_frame, 
            text="Enable Object Detection", 
            variable=self.detection_var,
            command=self.update_detection
        )
        detection_check.pack(anchor=tk.W, padx=5, pady=2)
        
        self.servo_var = tk.BooleanVar(value=self.servo_enabled)
        servo_check = ttk.Checkbutton(
            control_frame, 
            text="Enable Robot Control", 
            variable=self.servo_var,
            command=self.update_servo
        )
        servo_check.pack(anchor=tk.W, padx=5, pady=2)
        
        button_frame = ttk.Frame(control_frame)
        button_frame.pack(anchor=tk.W, fill=tk.X, pady=5)
        
        record_pose_btn = ttk.Button(
            button_frame,
            text="Record Pose",
            command=self.record_pose,
            style="Blue.TButton"
        )
        record_pose_btn.pack(side=tk.LEFT, padx=5)
        
        calibration_snapshot_btn = ttk.Button(
            button_frame,
            text="Capture Calibration Pose",
            command=self.capture_calibration_pose,
            style="Gold.TButton"
        )
        calibration_snapshot_btn.pack(side=tk.LEFT, padx=5)
        
        # Speed and smoothing controls
        speed_frame = ttk.LabelFrame(right_frame, text="Motion Settings")
        speed_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(speed_frame, text="Speed Factor:").pack(anchor=tk.W, padx=5, pady=2)
        
        speed_frame_inner = ttk.Frame(speed_frame)
        speed_frame_inner.pack(fill=tk.X, padx=5, pady=2)
        
        self.speed_value_label = ttk.Label(speed_frame_inner, text=f"{self.speed_factor:.1f}x", width=5)
        self.speed_value_label.pack(side=tk.RIGHT, padx=5)
        
        self.speed_slider = ttk.Scale(
            speed_frame_inner, 
            from_=0.5, 
            to=3.0,  # Increased maximum speed
            orient=tk.HORIZONTAL,
            value=self.speed_factor,
            command=self.update_speed
        )
        self.speed_slider.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        ttk.Label(speed_frame, text="Smoothing Factor:").pack(anchor=tk.W, padx=5, pady=2)
        
        smoothing_frame_inner = ttk.Frame(speed_frame)
        smoothing_frame_inner.pack(fill=tk.X, padx=5, pady=2)
        
        self.smoothing_value_label = ttk.Label(smoothing_frame_inner, text=f"{self.smoothing_factor:.2f}", width=5)
        self.smoothing_value_label.pack(side=tk.RIGHT, padx=5)
        
        self.smoothing_slider = ttk.Scale(
            smoothing_frame_inner, 
            from_=0.01,  # Lower minimum for faster response
            to=0.9, 
            orient=tk.HORIZONTAL,
            value=self.smoothing_factor,
            command=self.update_smoothing
        )
        self.smoothing_slider.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Manual control frame with styled buttons
        manual_control_frame = ttk.LabelFrame(right_frame, text="Manual Control")
        manual_control_frame.pack(fill=tk.X, padx=5, pady=5)
        
        btn_frame = ttk.Frame(manual_control_frame)
        btn_frame.pack(pady=10)
        
        # Empty cell for spacing
        ttk.Label(btn_frame, text="").grid(row=0, column=0)
        
        forward_btn = ttk.Button(
            btn_frame, 
            text="Forward", 
            command=lambda: self.send_manual_command("forward"),
            style="Blue.TButton"
        )
        forward_btn.grid(row=0, column=1, padx=5, pady=5)
        
        # Empty cell for spacing
        ttk.Label(btn_frame, text="").grid(row=0, column=2)
        
        left_btn = ttk.Button(
            btn_frame, 
            text="Left", 
            command=lambda: self.send_manual_command("left"),
            style="Blue.TButton"
        )
        left_btn.grid(row=1, column=0, padx=5, pady=5)
        
        stop_btn = ttk.Button(
            btn_frame, 
            text="STOP", 
            command=lambda: self.send_manual_command("stop"),
            style="Stop.TButton"
        )
        stop_btn.grid(row=1, column=1, padx=5, pady=5)
        
        right_btn = ttk.Button(
            btn_frame, 
            text="Right", 
            command=lambda: self.send_manual_command("right"),
            style="Blue.TButton"
        )
        right_btn.grid(row=1, column=2, padx=5, pady=5)
        
        # Empty cell for spacing
        ttk.Label(btn_frame, text="").grid(row=2, column=0)
        
        backward_btn = ttk.Button(
            btn_frame, 
            text="Backward", 
            command=lambda: self.send_manual_command("backward"),
            style="Blue.TButton"
        )
        backward_btn.grid(row=2, column=1, padx=5, pady=5)
        
        # Empty cell for spacing
        ttk.Label(btn_frame, text="").grid(row=2, column=2)
        
        up_btn = ttk.Button(
            btn_frame, 
            text="Up", 
            command=lambda: self.send_manual_command("up"),
            style="Gold.TButton"
        )
        up_btn.grid(row=0, column=3, padx=5, pady=5)
        
        down_btn = ttk.Button(
            btn_frame, 
            text="Down", 
            command=lambda: self.send_manual_command("down"),
            style="Gold.TButton"
        )
        down_btn.grid(row=2, column=3, padx=5, pady=5)
        
        # Keyboard bindings
        self.root.bind('<w>', lambda e: self.send_manual_command("forward"))
        self.root.bind('<s>', lambda e: self.send_manual_command("backward"))
        self.root.bind('<a>', lambda e: self.send_manual_command("left"))
        self.root.bind('<d>', lambda e: self.send_manual_command("right"))
        self.root.bind('<q>', lambda e: self.send_manual_command("up"))
        self.root.bind('<e>', lambda e: self.send_manual_command("down"))
        self.root.bind('<space>', lambda e: self.send_manual_command("stop"))
        
        # Information frame
        info_frame = ttk.LabelFrame(right_frame, text="Information")
        info_frame.pack(fill=tk.X, padx=5, pady=5)
        
        info_text = "Keyboard Controls:\n"
        info_text += "W: Forward | S: Backward\n"
        info_text += "A: Left | D: Right\n"
        info_text += "Q: Up | E: Down\n"
        info_text += "Space: Stop\n\n"
        info_text += "Calibration:\n"
        info_text += "Move robot to position, ensure checkerboard is visible,\n"
        info_text += "then click 'Capture Calibration Pose'.\n"
        info_text += "Repeat for at least 5 positions."
        
        info_label = ttk.Label(info_frame, text=info_text, style="Info.TLabel")
        info_label.pack(anchor=tk.W, padx=5, pady=2)
        
        # TF information frame with scrolling capability
        tf_frame = ttk.LabelFrame(right_frame, text="TF Information")
        tf_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Use a scrolled text widget for TF info to avoid truncation
        self.tf_text = scrolledtext.ScrolledText(tf_frame, height=5, width=30, wrap=tk.WORD)
        self.tf_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=2)
        self.tf_text.insert(tk.END, "Base to Tool0: Waiting...\n")
        self.tf_text.insert(tk.END, "Tool0 to ZED: Waiting...\n")
        self.tf_text.insert(tk.END, "ZED Link to Center: Waiting...\n")
        self.tf_text.config(state=tk.DISABLED)  # Make it read-only
        
        # Footer with copyright
        footer_frame = ttk.Frame(main_frame)
        footer_frame.pack(fill=tk.X, padx=5, pady=5)
        
        copyright_label = ttk.Label(
            footer_frame, 
            text="© Rise Baking Company - Robot Interface",
            foreground=self.company_blue,
            font=('Arial', 8)
        )
        copyright_label.pack(side=tk.RIGHT, padx=5)
        
        self.last_update_time = time.time()
        self.frame_count = 0
        self.last_gui_update = 0
        
        # Create initial watermark when the window size is known
        self.root.update_idletasks()
        width = self.camera_container.winfo_width()
        height = self.camera_container.winfo_height()
        if width > 10 and height > 10:  # Only create watermark if we have valid dimensions
            watermark = self.create_watermark(width, height)
            if watermark:
                self.watermark_tk = ImageTk.PhotoImage(watermark)
                self.watermark_label.config(image=self.watermark_tk)
        
        self.update_gui()
        self.root.mainloop()
    
    def toggle_camera_feed(self):
        self.show_raw_feed = self.show_raw_var.get()
    
    def update_detection(self):
        self.detection_enabled = self.detection_var.get()
        msg = Bool()
        msg.data = self.detection_enabled
        self.detection_enable_pub.publish(msg)
        
    def update_detection_mode(self):
        self.detection_mode = self.detection_mode_var.get()
        msg = String()
        msg.data = self.detection_mode
        self.detection_mode_pub.publish(msg)
        
    def update_servo(self):
        self.servo_enabled = self.servo_var.get()
        msg = Bool()
        msg.data = self.servo_enabled
        self.servo_enable_pub.publish(msg)
    
    def update_mode(self):
        self.robot_mode = self.mode_var.get()
        msg = String()
        msg.data = self.robot_mode
        self.mode_pub.publish(msg)
        
    def update_speed(self, value):
        self.speed_factor = float(value)
        self.speed_value_label.config(text=f"{self.speed_factor:.1f}x")
        msg = Float32()
        msg.data = self.speed_factor
        self.speed_pub.publish(msg)
        
    def update_smoothing(self, value):
        self.smoothing_factor = float(value)
        self.smoothing_value_label.config(text=f"{self.smoothing_factor:.2f}")
        msg = Float32()
        msg.data = self.smoothing_factor
        self.smoothing_pub.publish(msg)
    
    def send_manual_command(self, command):
        if self.robot_mode == "manual" and self.servo_enabled:
            msg = String()
            msg.data = command
            self.manual_command_pub.publish(msg)
        else:
            if self.robot_mode != "manual":
                self.get_logger().warn("Cannot send manual command in auto mode")
            elif not self.servo_enabled:
                self.get_logger().warn("Robot control is disabled")
    
    def record_pose(self):
        msg = Empty()
        self.record_pose_pub.publish(msg)
        self.get_logger().info("Triggered pose recording")
    
    def capture_calibration_pose(self):
        # Check if we're in calibration mode
        if self.detection_mode != "calibration":
            self.get_logger().warn("Switch to calibration mode first")
            return
            
        # Get robot pose (base to tool0)
        try:
            transform = self.tf_buffer.lookup_transform(
                'base',
                'tool0',
                rclpy.time.Time(),
                timeout=rclpy.duration.Duration(seconds=1.0)
            )
            robot_pose = PoseStamped()
            robot_pose.header.stamp = self.get_clock().now().to_msg()
            robot_pose.header.frame_id = 'base_to_tool0'
            robot_pose.pose.position.x = transform.transform.translation.x
            robot_pose.pose.position.y = transform.transform.translation.y
            robot_pose.pose.position.z = transform.transform.translation.z
            robot_pose.pose.orientation = transform.transform.rotation
        except Exception as e:
            self.get_logger().error(f"Failed to get robot pose: {str(e)}")
            return

        # Get checkerboard pose (zed_camera_center to checkerboard)
        if self.current_checkerboard_pose is None:
            self.get_logger().warn("No checkerboard detected, cannot capture pose")
            return

        # Combine into a single message (using checkerboard pose message with additional info)
        snapshot = PoseStamped()
        snapshot.header = self.current_checkerboard_pose.header
        snapshot.header.frame_id = 'calibration_snapshot'
        snapshot.pose = self.current_checkerboard_pose.pose

        # Store robot pose in unused fields (for simplicity; alternatively, create a custom msg)
        snapshot.pose.position.x = self.current_checkerboard_pose.pose.position.x
        snapshot.pose.position.y = self.current_checkerboard_pose.pose.position.y
        snapshot.pose.position.z = self.current_checkerboard_pose.pose.position.z
        snapshot.pose.orientation.x = self.current_checkerboard_pose.pose.orientation.x
        snapshot.pose.orientation.y = self.current_checkerboard_pose.pose.orientation.y
        snapshot.pose.orientation.z = self.current_checkerboard_pose.pose.orientation.z
        snapshot.pose.orientation.w = self.current_checkerboard_pose.pose.orientation.w

        # Publish snapshot
        self.calibration_snapshot_pub.publish(snapshot)
        self.get_logger().info("Captured calibration pose snapshot")

    def update_gui(self):
        """Update the GUI with fixed update rate to avoid blinking"""
        if self.root is None:
            return
            
        current_time = time.time()
        
        # Update status labels
        self.detector_status_label.config(text=f"Detector: {self.detector_status}")
        self.servo_status_label.config(text=f"Servo: {self.servo_status}")
        
        # Update camera coordinates display - show pixel coordinates for red object too
        if self.detection_mode == "calibration" and self.current_checkerboard_pose is not None:
            pose = self.current_checkerboard_pose.pose
            camera_coords_text = f"Camera Coords: X: {pose.position.x:.3f}, Y: {pose.position.y:.3f}, Z: {pose.position.z:.3f}"
            self.camera_coords_label.config(text=camera_coords_text, foreground="green")
        elif self.detection_mode == "red_object":
            # For red object, show pixel coordinates from detector status
            camera_coords_text = f"Pixel Coords: None"
            
            # Extract pixel coordinates from detector status
            if "Red object detected at pixel:" in self.detector_status:
                try:
                    pixelstr = self.detector_status.split("Red object detected at pixel:")[1].strip()
                    camera_coords_text = f"Pixel Coords: {pixelstr}"
                except:
                    pass
                    
            self.camera_coords_label.config(text=camera_coords_text, foreground="red")
        else:
            self.camera_coords_label.config(text="Pixel Coords: None", foreground="gray")
        
        if self.target_point is not None:
            target_text = f"Target: X: {self.target_point.x:.3f}, Y: {self.target_point.y:.3f}, Z: {self.target_point.z:.3f}"
            self.target_coords_label.config(text=target_text)
        
        # Update TF information - use scrolled text for better display
        self.tf_text.config(state=tk.NORMAL)  # Allow editing
        self.tf_text.delete(1.0, tk.END)  # Clear previous content
        
        try:
            self.base_to_tool0 = self.tf_buffer.lookup_transform(
                'base', 'tool0', rclpy.time.Time(), timeout=rclpy.duration.Duration(seconds=0.1))
            t = self.base_to_tool0.transform.translation
            self.tf_text.insert(tk.END, f"Base to Tool0: X: {t.x:.3f}, Y: {t.y:.3f}, Z: {t.z:.3f}\n")
        except Exception:
            self.tf_text.insert(tk.END, "Base to Tool0: Not available\n")
            
        try:
            self.tool0_to_zed_camera_link = self.tf_buffer.lookup_transform(
                'tool0', 'zed_camera_link', rclpy.time.Time(), timeout=rclpy.duration.Duration(seconds=0.1))
            t = self.tool0_to_zed_camera_link.transform.translation
            self.tf_text.insert(tk.END, f"Tool0 to ZED: X: {t.x:.3f}, Y: {t.y:.3f}, Z: {t.z:.3f}\n")
        except Exception:
            self.tf_text.insert(tk.END, "Tool0 to ZED: Not available\n")
            
        try:
            self.zed_camera_link_to_center = self.tf_buffer.lookup_transform(
                'zed_camera_link', 'zed_camera_center', rclpy.time.Time(), timeout=rclpy.duration.Duration(seconds=0.1))
            t = self.zed_camera_link_to_center.transform.translation
            self.tf_text.insert(tk.END, f"ZED Link to Center: X: {t.x:.3f}, Y: {t.y:.3f}, Z: {t.z:.3f}\n")
        except Exception:
            self.tf_text.insert(tk.END, "ZED Link to Center: Not available\n")
        
        self.tf_text.config(state=tk.DISABLED)  # Make read-only again
        
        # Update camera image - only if enough time has passed since last update (reduces blinking)
        if current_time - self.last_gui_update > 0.1:  # Maximum 10 FPS for GUI updates
            self.last_gui_update = current_time
            
            # Get the appropriate image to display
            image_to_display = None
            if self.show_raw_feed and self.latest_raw_image is not None:
                image_to_display = self.latest_raw_image.copy()
            elif not self.show_raw_feed and self.latest_processed_image is not None:
                image_to_display = self.latest_processed_image.copy()
            elif self.latest_processed_image is not None:
                image_to_display = self.latest_processed_image.copy()
            elif self.latest_raw_image is not None:
                image_to_display = self.latest_raw_image.copy()
                
            if image_to_display is not None:
                self.frame_count += 1
                elapsed = current_time - self.last_update_time
                
                if elapsed > 1.0:
                    fps = self.frame_count / elapsed
                    self.fps_label.config(text=f"FPS: {fps:.1f}")
                    self.frame_count = 0
                    self.last_update_time = current_time
                
                # Convert to RGB for PIL
                img = cv2.cvtColor(image_to_display, cv2.COLOR_BGR2RGB)
                
                # Get current dimensions of the container
                label_width = self.camera_container.winfo_width()
                label_height = self.camera_container.winfo_height()
                
                # Check if container size has changed and watermark needs to be regenerated
                if (self.watermark_tk is None or 
                    self.watermark_tk.width() != label_width or 
                    self.watermark_tk.height() != label_height) and label_width > 10 and label_height > 10:
                    watermark = self.create_watermark(label_width, label_height)
                    if watermark:
                        self.watermark_tk = ImageTk.PhotoImage(watermark)
                        self.watermark_label.config(image=self.watermark_tk)
                
                # Resize the image to fit the label while maintaining aspect ratio
                if label_width > 10 and label_height > 10:
                    img_height, img_width = img.shape[:2]
                    aspect_ratio = img_width / img_height
                    
                    if label_width / label_height > aspect_ratio:
                        new_height = label_height
                        new_width = int(aspect_ratio * new_height)
                    else:
                        new_width = label_width
                        new_height = int(new_width / aspect_ratio)
                        
                    img_resized = cv2.resize(img, (new_width, new_height), interpolation=cv2.INTER_AREA)
                    pil_img = PILImage.fromarray(img_resized)
                    self.image_tk = ImageTk.PhotoImage(image=pil_img)
                    self.image_label.config(image=self.image_tk, text="")
                else:
                    # If label is too small, just use the original image
                    pil_img = PILImage.fromarray(img)
                    self.image_tk = ImageTk.PhotoImage(image=pil_img)
                    self.image_label.config(image=self.image_tk, text="")
            else:
                self.image_label.config(image="", text="Waiting for camera feed...")
        
        # Schedule the next update
        self.root.after(30, self.update_gui)  # ~33 FPS max for GUI updates

def main(args=None):
    rclpy.init(args=args)
    gui_node = VisualServoGUI()
    from rclpy.executors import MultiThreadedExecutor
    executor = MultiThreadedExecutor(num_threads=4)
    executor.add_node(gui_node)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        gui_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
