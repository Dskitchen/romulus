#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, TransformStamped, PointStamped
from std_msgs.msg import Bool, String, Empty, Float32
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from sensor_msgs.msg import JointState
from tf2_msgs.msg import TFMessage
from builtin_interfaces.msg import Duration
import numpy as np
import math
import csv
import os

class VisualServoController(Node):
    def __init__(self):
        super().__init__('visual_servo_controller')
        
        # Parameters
        self.declare_parameter('servo_enabled', False)
        self.declare_parameter('manual_control_speed', 0.1)
        self.declare_parameter('max_speed', 0.2)
        self.declare_parameter('robot_mode', 'manual')
        self.declare_parameter('emergency_stop_timeout', 0.5)
        self.declare_parameter('pixel_error_threshold', 50.0)
        self.declare_parameter('servo_gain', 0.001)
        
        self.servo_enabled = self.get_parameter('servo_enabled').value
        self.manual_control_speed = self.get_parameter('manual_control_speed').value
        self.max_speed = self.get_parameter('max_speed').value
        self.robot_mode = self.get_parameter('robot_mode').value
        self.emergency_stop_timeout = self.get_parameter('emergency_stop_timeout').value
        self.pixel_error_threshold = self.get_parameter('pixel_error_threshold').value
        self.servo_gain = self.get_parameter('servo_gain').value
        self.speed_factor = 2.0  # Increased default speed factor
        
        # Add initialization waiting period to let camera stabilize
        self.enable_processing = False
        self.get_logger().info("Waiting for system to stabilize...")
        self.init_timer = self.create_timer(3.0, self.init_timer_callback)
        
        self.enable_sub = self.create_subscription(
            Bool, 
            '/visual_servo/enable', 
            self.enable_callback, 
            10)
            
        self.mode_sub = self.create_subscription(
            String, 
            '/visual_servo/mode', 
            self.mode_callback, 
            10)
            
        self.manual_command_sub = self.create_subscription(
            String, 
            '/visual_servo/manual_command', 
            self.manual_command_callback, 
            50)
            
        self.target_sub = self.create_subscription(
            PointStamped, 
            '/visual_servo/current_target', 
            self.target_callback, 
            10)
            
        self.joint_states_sub = self.create_subscription(
            JointState, 
            '/joint_states', 
            self.joint_states_callback, 
            10)
            
        self.record_pose_sub = self.create_subscription(
            Empty,
            '/visual_servo/record_pose',
            self.record_pose_callback,
            10)
        
        self.tf_sub = self.create_subscription(
            TFMessage,
            '/tf',
            self.tf_callback,
            10)
            
        # Subscribe to speed and smoothing factor control topics
        self.speed_factor_sub = self.create_subscription(
            Float32,
            '/visual_servo/speed_factor',
            self.speed_factor_callback,
            10)
            
        self.smoothing_factor_sub = self.create_subscription(
            Float32,
            '/visual_servo/smoothing_factor',
            self.smoothing_factor_callback,
            10)
        
        self.status_pub = self.create_publisher(
            String, 
            '/visual_servo/status', 
            10)
            
        self.trajectory_pub = self.create_publisher(
            JointTrajectory, 
            '/scaled_joint_trajectory_controller/joint_trajectory', 
            10)
            
        self.emergency_stop_pub = self.create_publisher(
            String,
            '/visual_servo/emergency_stop',
            10)
        
        self.joint_names = [
            'shoulder_pan_joint', 
            'shoulder_lift_joint', 
            'elbow_joint', 
            'wrist_1_joint', 
            'wrist_2_joint', 
            'wrist_3_joint'
        ]
        
        self.current_robot_pose = None
        self.current_robot_joints = None
        self.current_target = None
        self.last_command_time = self.get_clock().now()
        self.manual_velocity = [0.0, 0.0, 0.0]
        self.manual_direction = None
        
        # For smoothing joint positions
        self.prev_joint_positions = None
        self.smoothing_factor = 0.2  # Lower for faster response
        
        # For logging throttling
        self.log_counter = 0
        
        # CSV file to store TCP poses for conveyor location
        self.output_file = os.path.expanduser('~/conveyor_points.csv')
        with open(self.output_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                'robot_x', 'robot_y', 'robot_z', 'robot_qx', 'robot_qy', 'robot_qz', 'robot_qw'
            ])
        
        self.control_timer = None  # Will be created when system is ready
        self.emergency_stop_timer = self.create_timer(0.1, self.check_emergency_stop)
        
        self.get_logger().info('Visual servo controller initialized')
        
    def init_timer_callback(self):
        self.enable_processing = True
        self.get_logger().info("System stabilized, starting processing")
        self.control_timer = self.create_timer(0.1, self.control_loop)  # Slower 10 Hz control loop to reduce timing issues
        self.destroy_timer(self.init_timer)
        
    def check_emergency_stop(self):
        if not self.servo_enabled or not self.enable_processing:
            return
        current_time = self.get_clock().now()
        if self.robot_mode == 'manual' and any(v != 0.0 for v in self.manual_velocity):
            time_since_command = (current_time - self.last_command_time).nanoseconds / 1e9
            if time_since_command > self.emergency_stop_timeout:
                self.get_logger().warn(f"Manual command timeout after {time_since_command:.2f}s - stopping robot")
                self.manual_velocity = [0.0, 0.0, 0.0]
                self.manual_direction = None
                self.send_stop_command()
                msg = String()
                msg.data = "EMERGENCY STOP: Command timeout"
                self.emergency_stop_pub.publish(msg)
    
    def speed_factor_callback(self, msg):
        if not self.enable_processing:
            return
        self.speed_factor = msg.data
        self.log_counter += 1
        if self.log_counter % 50 == 0:  # Log less frequently
            self.get_logger().info(f"Speed factor updated to: {self.speed_factor:.2f}")
    
    def smoothing_factor_callback(self, msg):
        if not self.enable_processing:
            return
        self.smoothing_factor = msg.data
        self.log_counter += 1
        if self.log_counter % 50 == 0:  # Log less frequently
            self.get_logger().info(f"Smoothing factor updated to: {self.smoothing_factor:.2f}")
                
    def send_stop_command(self):
        try:
            trajectory = JointTrajectory()
            trajectory.header.stamp = self.get_clock().now().to_msg()
            trajectory.joint_names = self.joint_names
            point = JointTrajectoryPoint()
            if self.current_robot_joints:
                point.positions = list(self.current_robot_joints)
            else:
                point.positions = [0.0, -1.57, 0.0, -1.57, 0.0, 0.0]
            point.velocities = [0.0] * 6
            point.time_from_start = Duration(sec=0, nanosec=100000000)
            trajectory.points.append(point)
            self.get_logger().info("Publishing STOP trajectory")
            self.trajectory_pub.publish(trajectory)
            status_msg = String()
            status_msg.data = "Robot stopped"
            self.status_pub.publish(status_msg)
        except Exception as e:
            self.get_logger().error(f"Error sending stop command: {str(e)}")
        
    def joint_states_callback(self, msg):
        if not self.enable_processing:
            return
            
        if len(msg.name) >= 6:
            ur_joints = []
            positions = []
            for name, pos in zip(msg.name, msg.position):
                if name in self.joint_names:
                    ur_joints.append(name)
                    positions.append(pos)
            if len(ur_joints) == 6:
                joint_dict = dict(zip(ur_joints, positions))
                self.current_robot_joints = [joint_dict.get(name, 0.0) for name in self.joint_names]
        
    def tf_callback(self, msg):
        if not self.enable_processing:
            return
            
        for transform in msg.transforms:
            if transform.header.frame_id == 'base' and transform.child_frame_id == 'tool0_controller':
                self.current_robot_pose = transform
                self.log_counter += 1
                if self.log_counter % 100 == 0:  # Reduced logging frequency
                    self.get_logger().debug(f"Robot TCP pose: X={transform.transform.translation.x:.3f}, Y={transform.transform.translation.y:.3f}, Z={transform.transform.translation.z:.3f}")
                break
        
    def target_callback(self, msg):
        if not self.enable_processing:
            return
            
        self.current_target = msg
        self.log_counter += 1
        if self.log_counter % 50 == 0:  # Reduced logging frequency
            self.get_logger().debug(f"Target position: X={msg.point.x:.1f}, Y={msg.point.y:.1f}, Z={msg.point.z:.1f} (pixels)")
        
    def enable_callback(self, msg):
        self.servo_enabled = msg.data
        status_msg = String()
        status_msg.data = f"Visual servo {'enabled' if self.servo_enabled else 'disabled'}"
        self.status_pub.publish(status_msg)
        if not self.servo_enabled:
            self.current_target = None
            self.manual_velocity = [0.0, 0.0, 0.0]
            self.manual_direction = None
            self.send_stop_command()
        self.get_logger().info(f"Servo enabled: {self.servo_enabled}")
        
    def mode_callback(self, msg):
        if msg.data in ['manual', 'auto']:
            old_mode = self.robot_mode
            self.robot_mode = msg.data
            status_msg = String()
            status_msg.data = f"Changed from {old_mode} mode to {self.robot_mode} mode"
            self.status_pub.publish(status_msg)
            self.current_target = None
            self.manual_velocity = [0.0, 0.0, 0.0]
            self.manual_direction = None
            self.send_stop_command()
            self.get_logger().info(f"Robot mode: {self.robot_mode}")
        else:
            self.get_logger().error(f"Invalid mode: {msg.data}. Must be 'manual' or 'auto'")
    
    def manual_command_callback(self, msg):
        if not self.enable_processing:
            return
            
        self.last_command_time = self.get_clock().now()
        if self.robot_mode != 'manual':
            status_msg = String()
            status_msg.data = "Cannot execute manual command in auto mode"
            self.status_pub.publish(status_msg)
            return
        if msg.data in ['forward', 'backward', 'left', 'right', 'up', 'down', 'stop']:
            self.manual_direction = msg.data if msg.data != 'stop' else None
            adjusted_speed = self.manual_control_speed * self.speed_factor
            
            if msg.data == 'forward':
                self.manual_velocity = [adjusted_speed, 0.0, 0.0]
            elif msg.data == 'backward':
                self.manual_velocity = [-adjusted_speed, 0.0, 0.0]
            elif msg.data == 'left':
                self.manual_velocity = [0.0, adjusted_speed, 0.0]
            elif msg.data == 'right':
                self.manual_velocity = [0.0, -adjusted_speed, 0.0]
            elif msg.data == 'up':
                self.manual_velocity = [0.0, 0.0, adjusted_speed]
            elif msg.data == 'down':
                self.manual_velocity = [0.0, 0.0, -adjusted_speed]
            elif msg.data == 'stop':
                self.manual_velocity = [0.0, 0.0, 0.0]
            
            status_msg = String()
            if self.manual_direction:
                status_msg.data = f"Manual control: moving {self.manual_direction} (speed: {adjusted_speed:.2f})"
            else:
                status_msg.data = "Manual control: stopped"
            self.status_pub.publish(status_msg)
            if msg.data == 'stop':
                self.send_stop_command()
            self.log_counter += 1
            if self.log_counter % 50 == 0:  # Reduced logging frequency
                self.get_logger().info(f"Received manual command: {msg.data}")
        else:
            self.get_logger().error(f"Invalid manual command: {msg.data}")
        
    def record_pose_callback(self, msg):
        if not self.enable_processing:
            return
            
        self.get_logger().info("Attempting to record TCP pose for conveyor point...")
        
        robot_pos = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        if self.current_robot_pose:
            robot_pos = [
                self.current_robot_pose.transform.translation.x,
                self.current_robot_pose.transform.translation.y,
                self.current_robot_pose.transform.translation.z,
                self.current_robot_pose.transform.rotation.x,
                self.current_robot_pose.transform.rotation.y,
                self.current_robot_pose.transform.rotation.z,
                self.current_robot_pose.transform.rotation.w
            ]
            self.get_logger().info(f"Recording TCP pose: X={robot_pos[0]:.3f}, Y={robot_pos[1]:.3f}, Z={robot_pos[2]:.3f}")
        else:
            self.get_logger().warn("No recent robot TCP pose available for recording")
            return
        
        try:
            with open(self.output_file, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(robot_pos)
            self.get_logger().info(f"Recorded TCP pose for conveyor point: X={robot_pos[0]:.3f}, Y={robot_pos[1]:.3f}, Z={robot_pos[2]:.3f}")
        except Exception as e:
            self.get_logger().error(f"Failed to write to CSV: {str(e)}")
    
    def control_loop(self):
        if not self.servo_enabled or not self.enable_processing:
            return
            
        if self.robot_mode == 'manual' and any(v != 0.0 for v in self.manual_velocity):
            self.move_tool_velocity(self.manual_velocity[0], self.manual_velocity[1], self.manual_velocity[2], 0, 0, 0)
            self.log_counter += 1
            if self.log_counter % 20 == 0:  # Reduced logging frequency
                status_msg = String()
                status_msg.data = f"Manual: Moving {self.manual_direction} | Velocity: X={self.manual_velocity[0]:.3f}, Y={self.manual_velocity[1]:.3f}, Z={self.manual_velocity[2]:.3f}"
                self.status_pub.publish(status_msg)
            
        elif self.robot_mode == 'auto' and self.current_target is not None and self.servo_enabled:
            center_x = 580.0
            center_y = 390.0
            
            error_x = self.current_target.point.x - center_x
            error_y = self.current_target.point.y - center_y
            
            if abs(error_x) < self.pixel_error_threshold and abs(error_y) < self.pixel_error_threshold:
                self.get_logger().info("Target centered, stopping movement")
                self.send_stop_command()
                status_msg = String()
                status_msg.data = "Target centered"
                self.status_pub.publish(status_msg)
                return
                
            vx = 0.0
            vy = -self.servo_gain * error_x * self.speed_factor
            vz = -self.servo_gain * error_y * self.speed_factor
            
            magnitude = math.sqrt(vx**2 + vy**2 + vz**2)
            max_allowed_speed = self.max_speed * self.speed_factor
            if magnitude > max_allowed_speed:
                scale = max_allowed_speed / magnitude
                vx *= scale
                vy *= scale
                vz *= scale
                
            self.move_tool_velocity(vx, vy, vz, 0, 0, 0)
            
            self.log_counter += 1
            if self.log_counter % 20 == 0:  # Reduced logging frequency
                status_msg = String()
                status_msg.data = f"Auto: Servoing to target | Errors: X={error_x:.1f}, Y={error_y:.1f} | Velocity: X={vx:.3f}, Y={vy:.3f}, Z={vz:.3f}"
                self.status_pub.publish(status_msg)
                self.get_logger().debug(status_msg.data)
        else:
            self.log_counter += 1
            if self.log_counter % 200 == 0:  # Further reduced logging frequency
                self.get_logger().debug("Not servoing: mode or servo state not active")
        
    def get_movement_direction(self, vel_x, vel_y, vel_z):
        abs_vel = [abs(vel_x), abs(vel_y), abs(vel_z)]
        max_vel = max(abs_vel)
        if max_vel < 0.01:
            return "stationary"
        if abs_vel.index(max_vel) == 0:
            return "forward" if vel_x > 0 else "backward"
        elif abs_vel.index(max_vel) == 1:
            return "left" if vel_y > 0 else "right"
        else:
            return "up" if vel_z > 0 else "down"
            
    def move_tool_velocity(self, vx, vy, vz, wx, wy, wz):
        try:
            trajectory = JointTrajectory()
            # Use current time to ensure the timestamp is fresh
            now = self.get_clock().now().to_msg()
            trajectory.header.stamp = now
            trajectory.joint_names = self.joint_names
            point = JointTrajectoryPoint()
            
            if self.current_robot_joints:
                current_positions = list(self.current_robot_joints)
            else:
                current_positions = [0.0, -1.57, 0.0, -1.57, 0.0, 0.0]
                self.get_logger().warn("No current joint positions available, using defaults")
            
            joint_velocities = [0.0] * 6
            
            magnitudes = [abs(v) for v in [vx, vy, vz]]
            total_magnitude = sum(magnitudes)
            
            if total_magnitude > 0.01:
                if abs(vx) > 0.01:
                    joint_velocities[1] = -vx * 1.5
                    joint_velocities[2] = vx * 0.8
                    joint_velocities[3] = -vx * 0.5
                
                if abs(vy) > 0.01:
                    joint_velocities[0] = vy * 1.8
                
                if abs(vz) > 0.01:
                    joint_velocities[1] += vz * 0.3
                    joint_velocities[2] += vz * 0.7
                    joint_velocities[3] += -vz * 0.5
            
            duration = 0.1  # Increased duration to match control loop rate
            
            new_positions = [pos + vel * duration 
                            for pos, vel in zip(current_positions, joint_velocities)]
            
            if self.prev_joint_positions is not None:
                new_positions = [
                    self.smoothing_factor * prev + (1 - self.smoothing_factor) * new
                    for prev, new in zip(self.prev_joint_positions, new_positions)
                ]
            self.prev_joint_positions = new_positions.copy()
            
            point.positions = new_positions
            point.velocities = joint_velocities
            # Set time_from_start to a future time to avoid "ends in the past" errors
            point.time_from_start = Duration(sec=0, nanosec=int((duration + 0.05) * 1e9))  # Added 50ms buffer
            trajectory.points.append(point)
            
            self.trajectory_pub.publish(trajectory)
        except Exception as e:
            self.get_logger().error(f"Error moving robot: {str(e)}")

def main(args=None):
    rclpy.init(args=args)
    visual_servo_controller = VisualServoController()
    rclpy.spin(visual_servo_controller)
    visual_servo_controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
