#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo, CompressedImage
from geometry_msgs.msg import PoseStamped, PointStamped, Polygon, Point32
from std_msgs.msg import Bool, String
from cv_bridge import CvBridge, CvBridgeError
import cv2
import numpy as np
from ultralytics import YOLO
import torch
import os
import svg.path
import svgpathtools
from visualization_msgs.msg import Marker, MarkerArray

class EnhancedObjectDetector(Node):
    def __init__(self):
        super().__init__('enhanced_object_detector')
        
        # Parameters
        self.declare_parameter('detection_enabled', True)
        self.declare_parameter('model_path', 'best.pt')
        self.declare_parameter('confidence_threshold', 0.5)
        self.declare_parameter('svg_directory', os.path.expanduser('~/decoration_patterns'))
        
        # Load parameters
        self.detection_enabled = self.get_parameter('detection_enabled').value
        self.model_path = self.get_parameter('model_path').value
        self.confidence_threshold = self.get_parameter('confidence_threshold').value
        self.svg_directory = self.get_parameter('svg_directory').value
        
        # Initialize YOLO model
        self.model = YOLO(self.model_path)
        self.class_names = self.model.names
        self.get_logger().info(f"Loaded YOLO model with {len(self.class_names)} classes: {self.class_names}")
        
        # Bridge for image conversion
        self.bridge = CvBridge()
        
        # Other initializations from original code...
        
        # New publishers for cake detection
        self.cake_surface_pub = self.create_publisher(
            Polygon,
            '/object_detection/cake_surface',
            10)
            
        self.cake_type_pub = self.create_publisher(
            String,
            '/object_detection/cake_type',
            10)
            
        self.svg_pattern_pub = self.create_publisher(
            MarkerArray,
            '/object_detection/decoration_pattern',
            10)
        
        # Current SVG pattern
        self.current_svg_pattern = None
        self.available_patterns = self.load_available_patterns()
        
        # Subscribe to pattern selection
        self.pattern_select_sub = self.create_subscription(
            String,
            '/object_detection/select_pattern',
            self.pattern_select_callback,
            10)
        
        # Rest of the initialization...
    
    def load_available_patterns(self):
        patterns = {}
        if os.path.exists(self.svg_directory):
            for file in os.listdir(self.svg_directory):
                if file.endswith('.svg'):
                    pattern_name = os.path.splitext(file)[0]
                    pattern_path = os.path.join(self.svg_directory, file)
                    patterns[pattern_name] = pattern_path
        self.get_logger().info(f"Loaded {len(patterns)} SVG patterns: {list(patterns.keys())}")
        return patterns
    
    def pattern_select_callback(self, msg):
        pattern_name = msg.data
        if pattern_name in self.available_patterns:
            self.current_svg_pattern = pattern_name
            self.get_logger().info(f"Selected pattern: {pattern_name}")
        else:
            self.get_logger().error(f"Pattern '{pattern_name}' not found in available patterns")
    
    def process_image(self, cv_image, header):
        if not self.detection_enabled:
            return
        
        display_img = cv_image.copy()
        
        # Run YOLO detection
        results = self.model(cv_image)
        
        # Process detection results
        detected_cakes = []
        
        for r in results:
            boxes = r.boxes
            for box in boxes:
                # Get box coordinates
                x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                
                # Get confidence and class
                conf = box.conf[0].cpu().numpy()
                cls = int(box.cls[0].cpu().numpy())
                
                if conf < self.confidence_threshold:
                    continue
                
                # Get class name
                class_name = self.class_names[cls]
                
                # Check if it's a cake
                if class_name in ['round_cake', 'rectangular_cake', 'cylindrical_cake']:
                    detected_cakes.append({
                        'class': class_name,
                        'box': (x1, y1, x2, y2),
                        'confidence': conf
                    })
                    
                    # Draw on display image
                    cv2.rectangle(display_img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(display_img, f"{class_name} {conf:.2f}", 
                                (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        
        # If cakes were detected, process the largest one (or use another selection strategy)
        if detected_cakes:
            # Sort by area
            detected_cakes.sort(key=lambda x: (x['box'][2] - x['box'][0]) * (x['box'][3] - x['box'][1]), reverse=True)
            
            # Process the largest cake
            primary_cake = detected_cakes[0]
            x1, y1, x2, y2 = primary_cake['box']
            cake_type = primary_cake['class']
            
            # Extract the cake surface
            surface_contour = self.extract_cake_surface(cv_image, primary_cake)
            
            # Publish the cake surface as a polygon
            if surface_contour is not None:
                self.publish_cake_surface(surface_contour, cake_type, header)
                
                # Draw the contour
                cv2.drawContours(display_img, [surface_contour], -1, (0, 0, 255), 2)
                
                # If we have a selected pattern, visualize it
                if self.current_svg_pattern:
                    self.visualize_svg_on_cake(display_img, surface_contour, self.current_svg_pattern)
                
            # Update status
            status_msg = String()
            status_msg.data = f"Detected {cake_type} with surface area {len(surface_contour)} points"
            self.status_pub.publish(status_msg)
        else:
            # No cakes detected
            status_msg = String()
            status_msg.data = "No cakes detected"
            self.status_pub.publish(status_msg)
        
        # Publish the processed image
        try:
            self.processed_img_pub.publish(self.bridge.cv2_to_imgmsg(display_img, "bgr8"))
            
            # Publish compressed image
            compressed_msg = self.bridge.cv2_to_compressed_imgmsg(display_img)
            compressed_msg.header = header
            self.processed_img_compressed_pub.publish(compressed_msg)
        except CvBridgeError as e:
            self.get_logger().error(f"Error publishing processed image: {str(e)}")
    
    def extract_cake_surface(self, image, cake_detection):
        """Extract the top surface contour of a cake"""
        x1, y1, x2, y2 = cake_detection['box']
        cake_type = cake_detection['class']
        
        # Crop to the cake region
        cake_region = image[y1:y2, x1:x2]
        
        # Convert to grayscale
        gray = cv2.cvtColor(cake_region, cv2.COLOR_BGR2GRAY)
        
        # Apply different processing based on cake type
        if cake_type == 'round_cake':
            # For round cakes, use Hough Circle detection
            blurred = cv2.GaussianBlur(gray, (9, 9), 2)
            circles = cv2.HoughCircles(blurred, cv2.HOUGH_GRADIENT, dp=1, minDist=50,
                                      param1=50, param2=30, minRadius=20, maxRadius=100)
                                      
            if circles is not None:
                circles = np.uint16(np.around(circles))
                # Get the largest circle
                largest_circle = circles[0][0]
                cx, cy, r = largest_circle
                
                # Create a contour for the circle
                contour_points = []
                for angle in range(0, 360, 5):  # 5-degree steps
                    x = cx + int(r * np.cos(np.radians(angle)))
                    y = cy + int(r * np.sin(np.radians(angle)))
                    contour_points.append([x, y])
                
                contour = np.array(contour_points, dtype=np.int32)
                
                # Adjust for the cropped region
                contour[:, 0] += x1
                contour[:, 1] += y1
                
                return contour
                
        elif cake_type == 'rectangular_cake':
            # For rectangular cakes, use edge detection and contour finding
            edges = cv2.Canny(gray, 50, 150)
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            if contours:
                # Get the largest contour
                largest_contour = max(contours, key=cv2.contourArea)
                
                # Approximate the contour to get a rectangle
                epsilon = 0.02 * cv2.arcLength(largest_contour, True)
                approx = cv2.approxPolyDP(largest_contour, epsilon, True)
                
                # Adjust for the cropped region
                approx[:, 0, 0] += x1
                approx[:, 0, 1] += y1
                
                return approx
                
        elif cake_type == 'cylindrical_cake':
            # For cylindrical cakes, use a combination of techniques
            # This is similar to round but we might adjust for perspective
            blurred = cv2.GaussianBlur(gray, (9, 9), 2)
            circles = cv2.HoughCircles(blurred, cv2.HOUGH_GRADIENT, dp=1, minDist=50,
                                      param1=50, param2=30, minRadius=20, maxRadius=100)
                                      
            if circles is not None:
                circles = np.uint16(np.around(circles))
                largest_circle = circles[0][0]
                cx, cy, r = largest_circle
                
                # Create an ellipse instead of a circle for perspective
                contour_points = []
                for angle in range(0, 360, 5):
                    # Use ellipse parameters (a for horizontal, b for vertical)
                    a = r
                    b = r * 0.8  # Slightly squashed for perspective
                    x = cx + int(a * np.cos(np.radians(angle)))
                    y = cy + int(b * np.sin(np.radians(angle)))
                    contour_points.append([x, y])
                
                contour = np.array(contour_points, dtype=np.int32)
                
                # Adjust for the cropped region
                contour[:, 0] += x1
                contour[:, 1] += y1
                
                return contour
        
        # Default fallback: use simple thresholding and contour finding
        ret, thresh = cv2.threshold(gray, 127, 255, 0)
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            largest_contour[:, 0, 0] += x1
            largest_contour[:, 0, 1] += y1
            return largest_contour
            
        return None
    
    def publish_cake_surface(self, contour, cake_type, header):
        """Publish the cake surface as a polygon message"""
        # Create a polygon message
        polygon_msg = Polygon()
        polygon_msg.points = []
        
        for point in contour:
            p = Point32()
            # If point is a 2D array with shape (1,2), extract the values
            if len(point.shape) > 1:
                p.x = float(point[0][0])
                p.y = float(point[0][1])
            else:
                p.x = float(point[0])
                p.y = float(point[1])
            p.z = 0.0
            polygon_msg.points.append(p)
        
        # Publish the polygon
        self.cake_surface_pub.publish(polygon_msg)
        
        # Publish the cake type
        type_msg = String()
        type_msg.data = cake_type
        self.cake_type_pub.publish(type_msg)
    
    def visualize_svg_on_cake(self, image, cake_contour, pattern_name):
        """Visualize the SVG pattern on the cake"""
        if pattern_name not in self.available_patterns:
            return
            
        svg_path = self.available_patterns[pattern_name]
        
        try:
            # Load the SVG file
            paths, attributes = svgpathtools.svg2paths(svg_path)
            
            # Calculate cake centroid and size
            M = cv2.moments(cake_contour)
            cx = int(M['m10'] / M['m00'])
            cy = int(M['m01'] / M['m00'])
            
            # Calculate scale factor
            contour_area = cv2.contourArea(cake_contour)
            scale_factor = np.sqrt(contour_area) / 100  # Adjust as needed
            
            # Draw each path
            for path in paths:
                # Sample points along the path
                num_points = 100
                for i in range(num_points):
                    t = i / (num_points - 1)
                    point = path.point(t)
                    
                    # Convert complex to x,y and scale/center
                    x = int(cx + point.real * scale_factor)
                    y = int(cy + point.imag * scale_factor)
                    
                    # Draw point on image
                    cv2.circle(image, (x, y), 2, (255, 0, 255), -1)
            
            # Publish the pattern as a marker array for visualization
            marker_array = MarkerArray()
            # ...add markers for each path segment...
            self.svg_pattern_pub.publish(marker_array)
            
        except Exception as e:
            self.get_logger().error(f"Error processing SVG: {str(e)}")
